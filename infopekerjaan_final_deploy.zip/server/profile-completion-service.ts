import { storage } from './storage';
import { 
  InsertProfileCompletionItem,
  InsertUserProfileCompletion
} from '@shared/schema';

/**
 * Service untuk mengelola fitur Profile Completion.
 */
export class ProfileCompletionService {
  /**
   * Mendapatkan semua item profil completion berdasarkan tipe pengguna
   */
  async getCompletionItems(userType?: string) {
    return storage.getProfileCompletionItems(userType);
  }
  
  /**
   * Mendapatkan item profil completion berdasarkan ID
   */
  async getCompletionItem(id: number) {
    return storage.getProfileCompletionItem(id);
  }
  
  /**
   * Membuat item profil completion baru
   */
  async createCompletionItem(item: InsertProfileCompletionItem) {
    return storage.createProfileCompletionItem(item);
  }
  
  /**
   * Mendapatkan semua status profil completion untuk pengguna
   */
  async getUserCompletions(userId: number) {
    return storage.getUserProfileCompletions(userId);
  }
  
  /**
   * Mendapatkan status profil completion tertentu
   */
  async getUserCompletion(userId: number, itemId: number) {
    return storage.getUserProfileCompletion(userId, itemId);
  }
  
  /**
   * Membuat status profil completion baru
   */
  async createUserCompletion(completion: InsertUserProfileCompletion) {
    return storage.createUserProfileCompletion(completion);
  }
  
  /**
   * Mengupdate status profil completion
   */
  async updateUserCompletion(userId: number, itemId: number, completed: boolean) {
    return storage.updateUserProfileCompletion(userId, itemId, completed);
  }
  
  /**
   * Menghitung persentase kelengkapan profil
   */
  async calculateCompletionPercentage(userId: number) {
    return storage.calculateProfileCompletionPercentage(userId);
  }
  
  /**
   * Menginisialisasi status profil completion untuk pengguna baru.
   * Dipanggil saat user baru mendaftar.
   */
  async initializeProfileCompletion(userId: number, userType: string) {
    // Dapatkan semua item yang sesuai dengan tipe pengguna
    const items = await this.getCompletionItems(userType);
    
    // Buat status completion kosong untuk setiap item
    const completions = await Promise.all(
      items.map(item => 
        this.createUserCompletion({
          userId,
          itemId: item.id,
          completed: false
        })
      )
    );
    
    return completions;
  }
  
  /**
   * Memeriksa dan memperbarui status completion untuk item tertentu.
   * Metode ini akan dipanggil ketika pengguna memperbarui profilnya.
   */
  async checkAndUpdateCompletion(userId: number, itemId: number, isCompleted: boolean) {
    const existingCompletion = await this.getUserCompletion(userId, itemId);
    
    if (existingCompletion) {
      if (existingCompletion.completed !== isCompleted) {
        return this.updateUserCompletion(userId, itemId, isCompleted);
      }
      return existingCompletion;
    } else {
      return this.createUserCompletion({
        userId,
        itemId,
        completed: isCompleted
      });
    }
  }
  
  /**
   * Mendapatkan data lengkap untuk profile completion dashboard
   */
  async getProfileCompletionDashboard(userId: number) {
    // Dapatkan user untuk mengetahui tipenya
    const user = await storage.getUser(userId);
    if (!user) {
      throw new Error('User not found');
    }
    
    // Dapatkan semua item yang relevan
    const items = await this.getCompletionItems(user.type);
    
    // Dapatkan status completion
    const completions = await this.getUserCompletions(userId);
    
    // Hitung persentase
    const percentage = await this.calculateCompletionPercentage(userId);
    
    // Gabungkan items dan completions
    const itemsWithStatus = items.map(item => {
      const completion = completions.find(c => c.itemId === item.id);
      return {
        ...item,
        completed: completion ? completion.completed : false,
        completedAt: completion ? completion.completedAt : null
      };
    });
    
    // Kelompokkan berdasarkan kategori
    const groupedItems: Record<string, any[]> = {};
    itemsWithStatus.forEach(item => {
      if (!groupedItems[item.category]) {
        groupedItems[item.category] = [];
      }
      groupedItems[item.category].push(item);
    });
    
    return {
      percentage,
      items: itemsWithStatus,
      groupedItems,
      totalItems: items.length,
      completedItems: completions.filter(c => c.completed).length
    };
  }
}

export const profileCompletionService = new ProfileCompletionService();