import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Helmet } from "react-helmet";
import MainLayout from "@/components/layout/main-layout";
import SearchForm from "@/components/search-form";
import JobCard from "@/components/job-card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { X } from "lucide-react";

const ITEMS_PER_PAGE = 10;

const SearchPage = () => {
  const [location] = useLocation();
  const [page, setPage] = useState(1);
  const [searchParams, setSearchParams] = useState<Record<string, string>>({});
  const [activeFilters, setActiveFilters] = useState<Record<string, string>>({});

  // Parse URL parameters
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const paramsObj: Record<string, string> = {};
    const filtersObj: Record<string, string> = {};
    
    params.forEach((value, key) => {
      paramsObj[key] = value;
      
      // Add to active filters for display (except pagination params)
      if (key !== 'page' && value) {
        filtersObj[key] = value;
      }
    });
    
    setSearchParams(paramsObj);
    setActiveFilters(filtersObj);
    
    // Get page from URL or default to 1
    const pageParam = params.get('page');
    setPage(pageParam ? parseInt(pageParam) : 1);
  }, [location]);

  // Transform search params for the API
  const getQueryParams = () => {
    const apiParams: Record<string, string> = { ...searchParams };
    
    // Add pagination
    apiParams.limit = ITEMS_PER_PAGE.toString();
    apiParams.offset = ((page - 1) * ITEMS_PER_PAGE).toString();
    
    return apiParams;
  };

  // Fetch jobs based on search params
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['/api/jobs', getQueryParams()],
    queryFn: async ({ queryKey }) => {
      const [_, params] = queryKey;
      const queryString = new URLSearchParams(params as Record<string, string>).toString();
      const response = await fetch(`/api/jobs?${queryString}`);
      
      if (!response.ok) {
        throw new Error('Failed to fetch jobs');
      }
      
      return response.json();
    }
  });

  // Clear a specific filter
  const removeFilter = (key: string) => {
    const newParams = new URLSearchParams(window.location.search);
    newParams.delete(key);
    
    window.history.pushState(
      {}, 
      '', 
      `${window.location.pathname}?${newParams.toString()}`
    );
    
    // Trigger a refetch with updated params
    const newParamsObj: Record<string, string> = {};
    newParams.forEach((value, key) => {
      newParamsObj[key] = value;
    });
    
    setSearchParams(newParamsObj);
    refetch();
  };

  // Clear all filters
  const clearAllFilters = () => {
    window.history.pushState({}, '', window.location.pathname);
    setSearchParams({});
    setActiveFilters({});
    refetch();
  };

  // Get readable filter names
  const getFilterLabel = (key: string, value: string) => {
    switch (key) {
      case 'query':
        return `Kata kunci: ${value}`;
      case 'location':
        return `Lokasi: ${value}`;
      case 'industry':
        return `Industri: ${value}`;
      case 'type':
        return `Tipe: ${value === 'full-time' ? 'Penuh Waktu' : 
                        value === 'part-time' ? 'Paruh Waktu' : 
                        value === 'contract' ? 'Kontrak' : 
                        value === 'remote' ? 'Remote' : value}`;
      case 'careerLevel':
        return `Level: ${value}`;
      case 'minSalary':
        return `Gaji Min: Rp${value}jt`;
      case 'maxSalary':
        return `Gaji Max: Rp${value}jt`;
      case 'remote':
        return 'Remote';
      default:
        return `${key}: ${value}`;
    }
  };

  return (
    <MainLayout>
      <Helmet>
        <title>Cari Lowongan Kerja - infopekerjaan.id</title>
        <meta name="description" content="Temukan lowongan pekerjaan sesuai dengan keahlian, lokasi, dan preferensi Anda di infopekerjaan.id" />
      </Helmet>

      <div className="bg-secondary-50 py-8">
        <div className="container mx-auto px-4">
          <div className="mb-8">
            <h1 className="text-2xl md:text-3xl font-bold text-secondary-900 mb-2">Cari Lowongan Kerja</h1>
            <p className="text-secondary-600">Temukan pekerjaan impian Anda dari ribuan lowongan terbaru</p>
          </div>

          {/* Search Form */}
          <SearchForm 
            compact 
            initialValues={{
              query: searchParams.query,
              location: searchParams.location,
              industry: searchParams.industry,
              type: searchParams.type,
              careerLevel: searchParams.careerLevel,
              minSalary: searchParams.minSalary ? parseInt(searchParams.minSalary) : undefined,
              maxSalary: searchParams.maxSalary ? parseInt(searchParams.maxSalary) : undefined,
              remote: searchParams.remote === 'true',
            }}
          />

          {/* Active Filters */}
          {Object.keys(activeFilters).length > 0 && (
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="text-sm text-secondary-600">Filter aktif:</span>
              {Object.entries(activeFilters).map(([key, value]) => (
                <Badge 
                  key={key}
                  variant="secondary"
                  className="flex items-center gap-1 bg-white"
                >
                  {getFilterLabel(key, value)}
                  <button
                    onClick={() => removeFilter(key)}
                    className="ml-1 text-secondary-500 hover:text-secondary-700"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
              <Button 
                variant="link" 
                size="sm" 
                onClick={clearAllFilters}
                className="text-primary hover:text-primary-700"
              >
                Reset semua
              </Button>
            </div>
          )}

          {/* Search Results */}
          <div className="mt-8">
            {isLoading ? (
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm border border-secondary-200 p-5">
                    <div className="flex items-start">
                      <Skeleton className="h-12 w-12 rounded" />
                      <div className="ml-4 space-y-2">
                        <Skeleton className="h-6 w-40" />
                        <Skeleton className="h-4 w-32" />
                      </div>
                    </div>
                    <div className="mt-4 space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-2/3" />
                    </div>
                  </div>
                ))}
              </div>
            ) : error ? (
              <div className="bg-white rounded-lg p-8 text-center">
                <h3 className="text-xl font-semibold text-secondary-900 mb-2">Terjadi kesalahan</h3>
                <p className="text-secondary-600 mb-4">Gagal memuat lowongan kerja. Silakan coba lagi.</p>
                <Button onClick={() => refetch()}>Coba Lagi</Button>
              </div>
            ) : data?.length === 0 ? (
              <div className="bg-white rounded-lg p-8 text-center">
                <h3 className="text-xl font-semibold text-secondary-900 mb-2">Lowongan Tidak Ditemukan</h3>
                <p className="text-secondary-600 mb-4">
                  Tidak ada lowongan yang sesuai dengan filter Anda. Coba ubah filter atau cari dengan kata kunci lain.
                </p>
                <Button onClick={clearAllFilters}>Reset Filter</Button>
              </div>
            ) : (
              <>
                <div className="mb-4">
                  <p className="text-secondary-600">
                    Menampilkan {data.length} lowongan
                  </p>
                </div>
                <div className="space-y-4">
                  {data.map((job: any) => (
                    <JobCard key={job.id} job={job} />
                  ))}
                </div>
                
                {/* Pagination - For future implementation */}
                {data.length >= ITEMS_PER_PAGE && (
                  <div className="mt-8 flex justify-center">
                    <Button 
                      variant="outline" 
                      className="mx-2"
                      disabled={page === 1}
                      onClick={() => setPage(prev => Math.max(prev - 1, 1))}
                    >
                      Sebelumnya
                    </Button>
                    <Button 
                      variant="outline" 
                      className="mx-2"
                      onClick={() => setPage(prev => prev + 1)}
                    >
                      Berikutnya
                    </Button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default SearchPage;
