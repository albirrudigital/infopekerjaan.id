import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ui/theme-provider";
import { AuthProvider } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import HomePage from "@/pages/home-page";
import AuthPage from "@/pages/auth-page";
import SearchPage from "@/pages/search-page";
import JobDetailPage from "@/pages/job-detail-page";
import CompanyProfilePage from "@/pages/company-profile-page";
import JobseekerDashboard from "@/pages/jobseeker-dashboard";
import EmployerDashboard from "@/pages/employer-dashboard";
import BekasiCompaniesPage from "@/pages/bekasi-companies-page";
import FeaturesPage from "@/pages/features-page";
import AdminDashboardPage from "@/pages/admin-dashboard-page";
import MarketInsightsPage from "@/pages/market-insights-page";
import AchievementsPage from "@/pages/achievements-page";
import MoodTrackerPage from "@/pages/mood-tracker-page";
import NotFound from "@/pages/not-found";
import { ProtectedRoute } from "./lib/protected-route";
import { useAuth } from "@/hooks/use-auth";

// Fungsi untuk membatasi akses ke halaman admin
const AdminRoute = ({ component: Component, path }: { component: React.ComponentType, path: string }) => {
  const { user } = useAuth();
  
  return (
    <Route path={path}>
      {user && user.type === 'admin' ? <Component /> : <NotFound />}
    </Route>
  );
};

function Router() {
  return (
    <Switch>
      <Route path="/" component={HomePage} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/search" component={SearchPage} />
      <Route path="/jobs/:id" component={JobDetailPage} />
      <Route path="/companies/:id" component={CompanyProfilePage} />
      <Route path="/bekasi-companies" component={BekasiCompaniesPage} />
      <Route path="/features" component={FeaturesPage} />
      <ProtectedRoute path="/market-insights" component={MarketInsightsPage} />
      <ProtectedRoute path="/achievements" component={AchievementsPage} />
      <ProtectedRoute path="/mood-tracker" component={MoodTrackerPage} />
      <ProtectedRoute path="/jobseeker/dashboard" component={JobseekerDashboard} />
      <ProtectedRoute path="/employer/dashboard" component={EmployerDashboard} />
      <AdminRoute path="/admin" component={AdminDashboardPage} />
      <AdminRoute path="/admin/dashboard" component={AdminDashboardPage} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <ThemeProvider defaultTheme="light" storageKey="infopekerjaan-theme">
          <TooltipProvider>
            <div className="min-h-screen flex flex-col">
              <Header />
              <main className="flex-1">
                <Router />
              </main>
            </div>
            <Toaster />
          </TooltipProvider>
        </ThemeProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
