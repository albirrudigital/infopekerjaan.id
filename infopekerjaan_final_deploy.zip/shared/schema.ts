import { pgTable, text, serial, integer, boolean, timestamp, jsonb, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// USERS
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  type: text("type", { enum: ["jobseeker", "employer", "admin"] }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// COMPANIES
export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  logo: text("logo"),
  industry: text("industry").notNull(),
  location: text("location").notNull(),
  description: text("description").notNull(),
  website: text("website"),
  employerId: integer("employer_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  verified: boolean("verified").default(false).notNull(),
});

export const insertCompanySchema = createInsertSchema(companies).omit({
  id: true,
  createdAt: true,
  verified: true,
});

export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

// JOBS
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  companyId: integer("company_id").notNull(),
  location: text("location").notNull(),
  type: text("type", { enum: ["full-time", "part-time", "contract", "remote"] }).notNull(),
  salary: text("salary").notNull(),
  description: text("description").notNull(),
  requirements: text("requirements").notNull(),
  industry: text("industry").notNull(),
  careerLevel: text("career_level").notNull(),
  skills: text("skills").array().notNull(),
  postedBy: integer("posted_by").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true).notNull(),
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
  isActive: true,
});

export type InsertJob = z.infer<typeof insertJobSchema>;
export type Job = typeof jobs.$inferSelect;

// JOB APPLICATIONS
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  jobId: integer("job_id").notNull(),
  jobseekerId: integer("jobseeker_id").notNull(),
  cv: text("cv").notNull(),
  coverLetter: text("cover_letter"),
  status: text("status", {
    enum: ["pending", "reviewed", "shortlisted", "rejected", "hired"],
  }).default("pending").notNull(),
  appliedAt: timestamp("applied_at").defaultNow().notNull(),
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  status: true,
  appliedAt: true,
});

export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Application = typeof applications.$inferSelect;

// JOBSEEKER PROFILES
export const jobseekerProfiles = pgTable("jobseeker_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  headline: text("headline"),
  summary: text("summary"),
  experiences: jsonb("experiences").array(),
  education: jsonb("education").array(),
  skills: text("skills").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertJobseekerProfileSchema = createInsertSchema(jobseekerProfiles).omit({
  id: true,
  createdAt: true,
});

export type InsertJobseekerProfile = z.infer<typeof insertJobseekerProfileSchema>;
export type JobseekerProfile = typeof jobseekerProfiles.$inferSelect;

// JOB CATEGORIES
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  icon: text("icon").notNull(),
  jobCount: integer("job_count").default(0).notNull(),
});

export const insertCategorySchema = createInsertSchema(categories).omit({
  id: true,
});

export type InsertCategory = z.infer<typeof insertCategorySchema>;
export type Category = typeof categories.$inferSelect;

// BLOG POSTS
export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  image: text("image"),
  category: text("category").notNull(),
  authorId: integer("author_id").notNull(),
  publishedAt: timestamp("published_at").defaultNow().notNull(),
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({
  id: true,
  publishedAt: true,
});

export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type BlogPost = typeof blogPosts.$inferSelect;

// LABOR REGULATIONS
export const laborRegulations = pgTable("labor_regulations", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  province: text("province").notNull(),
  city: text("city"),
  category: text("category", {
    enum: ["upah_minimum", "tenaga_kerja_asing", "keselamatan_kerja", "asuransi", "phk", "lainnya"]
  }).notNull(),
  effectiveDate: date("effective_date").notNull(),
  expiryDate: date("expiry_date"),
  documentUrl: text("document_url"),
  authorId: integer("author_id").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertLaborRegulationSchema = createInsertSchema(laborRegulations).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertLaborRegulation = z.infer<typeof insertLaborRegulationSchema>;
export type LaborRegulation = typeof laborRegulations.$inferSelect;

// PROVINCES
export const provinces = pgTable("provinces", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  code: text("code").notNull().unique(),
});

export const insertProvinceSchema = createInsertSchema(provinces).omit({
  id: true,
});

export type InsertProvince = z.infer<typeof insertProvinceSchema>;
export type Province = typeof provinces.$inferSelect;

// CITIES
export const cities = pgTable("cities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  provinceId: integer("province_id").notNull(),
  code: text("code").notNull().unique(),
  minimumWage: integer("minimum_wage"),
  sectorMinimumWages: jsonb("sector_minimum_wages"),
});

export const insertCitySchema = createInsertSchema(cities).omit({
  id: true,
});

export type InsertCity = z.infer<typeof insertCitySchema>;
export type City = typeof cities.$inferSelect;

// COMPANIES DATA FOR LABOR REGULATION
export const companyRegulations = pgTable("company_regulations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address"),
  district: text("district"),
  city: text("city"),
  province: text("province"),
  businessType: text("business_type"),
  status: text("status"),
  employeeCount: integer("employee_count").default(0),
  taxId: text("tax_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertCompanyRegulationSchema = createInsertSchema(companyRegulations).omit({
  id: true,
  createdAt: true,
});

export type InsertCompanyRegulation = z.infer<typeof insertCompanyRegulationSchema>;
export type CompanyRegulation = typeof companyRegulations.$inferSelect;

// NOTIFICATIONS
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull(),
  data: jsonb("data"),
  isRead: boolean("is_read").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertNotificationSchema = createInsertSchema(notifications).omit({
  id: true,
  isRead: true,
  createdAt: true,
});

export type InsertNotification = z.infer<typeof insertNotificationSchema>;
export type Notification = typeof notifications.$inferSelect;

// USER NOTIFICATION PREFERENCES
export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().unique(),
  email: boolean("email").default(true).notNull(),
  inApp: boolean("in_app").default(true).notNull(),
  push: boolean("push").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertNotificationPreferencesSchema = createInsertSchema(notificationPreferences).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertNotificationPreferences = z.infer<typeof insertNotificationPreferencesSchema>;
export type NotificationPreferences = typeof notificationPreferences.$inferSelect;

// ACHIEVEMENT EVENTS
export const achievementEvents = pgTable("achievement_events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  achievementId: text("achievement_id").notNull(),
  achievementName: text("achievement_name").notNull(),
  achievementType: text("achievement_type").notNull(), 
  achievementLevel: text("achievement_level", { 
    enum: ["bronze", "silver", "gold", "platinum"] 
  }).notNull(),
  unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
});

export const insertAchievementEventSchema = createInsertSchema(achievementEvents).omit({
  id: true,
  unlockedAt: true,
});

export type InsertAchievementEvent = z.infer<typeof insertAchievementEventSchema>;
export type AchievementEvent = typeof achievementEvents.$inferSelect;

// MOOD AND MOTIVATION TRACKER
export const moodEntries = pgTable("mood_entries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  date: timestamp("date").defaultNow().notNull(),
  mood: text("mood", { 
    enum: ["very_high", "high", "moderate", "low", "very_low"] 
  }).notNull(),
  notes: text("notes"),
  activities: text("activities").array().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMoodEntrySchema = createInsertSchema(moodEntries).omit({
  id: true,
  createdAt: true,
});

export type InsertMoodEntry = z.infer<typeof insertMoodEntrySchema>;
export type MoodEntry = typeof moodEntries.$inferSelect;

// MOTIVATION TIPS
export const motivationTips = pgTable("motivation_tips", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category", {
    enum: ["career_development", "mental_health", "job_search", "interview_preparation", "networking"]
  }).notNull(),
  targetMotivation: text("target_motivation", {
    enum: ["very_high", "high", "moderate", "low", "very_low"]
  }).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMotivationTipSchema = createInsertSchema(motivationTips).omit({
  id: true,
  isActive: true,
  createdAt: true,
});

export type InsertMotivationTip = z.infer<typeof insertMotivationTipSchema>;
export type MotivationTip = typeof motivationTips.$inferSelect;

// PROFILE COMPLETION PROGRESS
export const profileCompletionItems = pgTable("profile_completion_items", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description").notNull(),
  pointValue: integer("point_value").notNull(),
  category: text("category", {
    enum: ["basic_info", "professional_info", "documents", "preferences", "verification"]
  }).notNull(),
  userType: text("user_type", { enum: ["jobseeker", "employer", "both"] }).notNull(),
  isRequired: boolean("is_required").default(true).notNull(),
  displayOrder: integer("display_order").notNull(),
  iconName: text("icon_name"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertProfileCompletionItemSchema = createInsertSchema(profileCompletionItems).omit({
  id: true, 
  createdAt: true,
});

export type InsertProfileCompletionItem = z.infer<typeof insertProfileCompletionItemSchema>;
export type ProfileCompletionItem = typeof profileCompletionItems.$inferSelect;

// USER PROFILE COMPLETION STATUS
export const userProfileCompletions = pgTable("user_profile_completions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  itemId: integer("item_id").notNull(),
  completed: boolean("completed").default(false).notNull(),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const insertUserProfileCompletionSchema = createInsertSchema(userProfileCompletions).omit({
  id: true,
  completedAt: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUserProfileCompletion = z.infer<typeof insertUserProfileCompletionSchema>;
export type UserProfileCompletion = typeof userProfileCompletions.$inferSelect;
