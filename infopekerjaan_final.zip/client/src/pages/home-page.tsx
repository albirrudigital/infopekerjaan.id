import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { Search, LucideSearch, Building, Search as SearchIcon, Mouse, ChevronRight } from 'lucide-react';
import MainLayout from '@/components/layout/main-layout';
import { Input } from '@/components/ui/input';
import Logo from '@/components/ui/logo';

export default function HomePage() {
  const { user } = useAuth();
  
  return (
    <MainLayout>
      <Helmet>
        <title>Platform Rekrutmen Kerja di Indonesia</title>
        <meta name="description" content="Platform rekrutmen kerja terpercaya di Indonesia, menghubungkan pencari kerja dengan lowongan dari berbagai perusahaan." />
      </Helmet>
      
      {/* Hero Section dengan Search Box */}
      <section className="relative py-16 bg-white overflow-hidden">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center gap-8">
            {/* Konten Kiri */}
            <div className="w-full md:w-1/2 space-y-6">
              <h1 className="text-3xl md:text-5xl font-bold">
                Temukan <span className="text-primary">Pekerjaan Impian</span> Anda Bersama Kami
              </h1>
              
              <p className="text-gray-600 text-lg">
                Platform rekrutmen kerja terpercaya di Indonesia dengan ribuan lowongan dari perusahaan terkemuka di Indonesia.
              </p>
              
              {/* Search Box */}
              <div className="mt-8 space-y-4">
                <div className="relative">
                  <SearchIcon className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input 
                    type="text" 
                    placeholder="Posisi, perusahaan, atau keahlian" 
                    className="pl-10 pr-4 py-6 w-full rounded-md border border-gray-300 focus:border-primary focus:ring-primary"
                  />
                </div>
                
                <div className="relative">
                  <Building className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input 
                    type="text" 
                    placeholder="Kota atau provinsi" 
                    className="pl-10 pr-4 py-6 w-full rounded-md border border-gray-300 focus:border-primary focus:ring-primary"
                  />
                </div>
                
                <Link href="/search">
                  <Button className="w-full py-6" size="lg">
                    Cari Lowongan
                  </Button>
                </Link>
              </div>
            </div>
            
            {/* Gambar Kanan */}
            <div className="w-full md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" 
                alt="Person working on laptop" 
                className="w-full h-auto rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>
      
      {/* Fitur Unggulan */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-2xl md:text-3xl font-bold text-center mb-10">
            Fitur Unggulan
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Fitur 1 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <SearchIcon className="h-6 w-6 text-primary" />
                </div>
              </div>
              <h3 className="text-xl font-semibold text-center mb-2">Pencarian Cerdas</h3>
              <p className="text-gray-600 text-center">
                Temukan lowongan yang sesuai dengan keahlian dan preferensi Anda dengan sistem pencarian cerdas kami.
              </p>
            </div>
            
            {/* Fitur 2 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-primary">
                    <path d="M20 7h-3a2 2 0 0 1-2-2V2"></path>
                    <path d="M16 2H8a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path>
                    <path d="M12 13V7"></path>
                    <path d="M9 10h6"></path>
                  </svg>
                </div>
              </div>
              <h3 className="text-xl font-semibold text-center mb-2">Profil Profesional</h3>
              <p className="text-gray-600 text-center">
                Buat profil profesional yang menarik untuk mempersiapkan diri Anda bagi prosses rekrutmen.
              </p>
            </div>
            
            {/* Fitur 3 */}
            <div className="bg-white p-6 rounded-lg shadow-md">
              <div className="flex justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                  <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 text-primary">
                    <path d="M5.8 11.3 2 22l10.7-3.79"></path>
                    <path d="M4 3h.01M22 8h.01M15 2h.01M22 20h.01M22 2l-2.24.75a8 8 0 0 0-5.13 5.13L12 22"></path>
                    <path d="M17 6 6 17"></path>
                  </svg>
                </div>
              </div>
              <h3 className="text-xl font-semibold text-center mb-2">Apply Cepat</h3>
              <p className="text-gray-600 text-center">
                Lamar pekerjaan dengan cepat dan mudah menggunakan fitur Apply Cepat kami, tanpa proses yang rumit.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Call to Action untuk Memulai Karir */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-2xl md:text-3xl font-bold mb-6">
            Siap Untuk Memulai Karir Baru?
          </h2>
          
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto">
            Bergabunglah dengan ribuan pencari kerja yang telah menemukan pekerjaan impian mereka melalui platform kami.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth">
              <Button className="px-6 py-3">
                Daftar Sekarang
              </Button>
            </Link>
            
            <Link href="/search">
              <Button variant="outline" className="px-6 py-3">
                Cari Lowongan
              </Button>
            </Link>
          </div>
        </div>
      </section>
      
      {/* Footer */}
      <footer className="bg-gray-50 py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Kolom Perusahaan */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Perusahaan</h3>
              <ul className="space-y-2">
                <li><Link href="/jobs" className="text-gray-600 hover:text-primary">Posting Lowongan</Link></li>
                <li><Link href="/companies" className="text-gray-600 hover:text-primary">Hubungi Kami</Link></li>
                <li><Link href="/companies" className="text-gray-600 hover:text-primary">Karir</Link></li>
              </ul>
            </div>
            
            {/* Kolom Kandidat */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Kandidat</h3>
              <ul className="space-y-2">
                <li><Link href="/search" className="text-gray-600 hover:text-primary">Cari Lowongan</Link></li>
                <li><Link href="/companies" className="text-gray-600 hover:text-primary">Perusahaan di Bekasi</Link></li>
                <li><Link href="/regulations" className="text-gray-600 hover:text-primary">Regulasi Ketenagakerjaan</Link></li>
              </ul>
            </div>
            
            {/* Kolom Employer */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Employer</h3>
              <ul className="space-y-2">
                <li><Link href="/employer" className="text-gray-600 hover:text-primary">Posting Lowongan</Link></li>
                <li><Link href="/dashboard" className="text-gray-600 hover:text-primary">Dashboard Employer</Link></li>
                <li><Link href="/pricing" className="text-gray-600 hover:text-primary">Harga</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-200 mt-8 pt-8 text-center">
            <div className="mb-3 flex justify-center">
              <Logo size="md" />
            </div>
            <p className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} Hak Cipta Dilindungi.
            </p>
          </div>
        </div>
      </footer>
    </MainLayout>
  );
}