import { useQuery, useMutation } from '@tanstack/react-query';
import { queryClient, getQueryFn, apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';

/**
 * Hook untuk mengelola profile completion
 */
export function useProfileCompletion() {
  const { toast } = useToast();

  // Ambil data profile completion
  const {
    data: completionData,
    isLoading,
    error,
  } = useQuery({
    queryKey: ['/api/profile-completion'],
    queryFn: getQueryFn(),
  });

  // Ambil persentase completion
  const {
    data: percentageData,
    isLoading: isLoadingPercentage,
  } = useQuery({
    queryKey: ['/api/profile-completion/percentage'],
    queryFn: getQueryFn(),
  });

  // Mutasi untuk memperbarui status completion item
  const updateCompletionMutation = useMutation({
    mutationFn: async ({ itemId, completed }: { itemId: number; completed: boolean }) => {
      const res = await apiRequest('PATCH', `/api/profile-completion/${itemId}`, { completed });
      return res.json();
    },
    onSuccess: () => {
      // Invalidate queries untuk mereload data
      queryClient.invalidateQueries({ queryKey: ['/api/profile-completion'] });
      queryClient.invalidateQueries({ queryKey: ['/api/profile-completion/percentage'] });
    },
    onError: (error: any) => {
      toast({
        title: 'Gagal memperbarui status',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  return {
    completionData,
    percentage: percentageData?.percentage || 0,
    isLoading: isLoading || isLoadingPercentage,
    error,
    updateCompletion: updateCompletionMutation.mutate,
    isUpdating: updateCompletionMutation.isPending,
  };
}