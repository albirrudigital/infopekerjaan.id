import React from 'react';

function App() {
  return (
    <div>
      <h1>InfoPekerjaan.id Frontend Running</h1>
    </div>
  );
}

export default App;
