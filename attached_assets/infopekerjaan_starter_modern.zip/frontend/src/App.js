import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import UploadJob from './pages/UploadJob';
import ApplyForm from './pages/ApplyForm';
import Home from './pages/Home';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/upload-job" element={<UploadJob />} />
        <Route path="/apply" element={<ApplyForm />} />
      </Routes>
    </Router>
  );
}

export default App;
