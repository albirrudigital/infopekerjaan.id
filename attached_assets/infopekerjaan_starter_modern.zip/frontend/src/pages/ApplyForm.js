import React, { useState } from 'react';
import axios from 'axios';

function ApplyForm() {
  const [formData, setFormData] = useState({ jobId: '', name: '', email: '', resume: null });

  const handleChange = (e) => {
    if (e.target.name === 'resume') {
      setFormData({ ...formData, resume: e.target.files[0] });
    } else {
      setFormData({ ...formData, [e.target.name]: e.target.value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const data = new FormData();
    data.append('jobId', formData.jobId);
    data.append('name', formData.name);
    data.append('email', formData.email);
    data.append('resume', formData.resume);
    await axios.post(`${process.env.REACT_APP_API_URL}/api/jobs/apply`, data, { headers: { 'Content-Type': 'multipart/form-data' } });
    alert('Lamaran berhasil dikirim!');
    setFormData({ jobId: '', name: '', email: '', resume: null });
  };

  return (
    <div className="flex justify-center items-center h-screen">
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-md w-96" encType="multipart/form-data">
        <h2 className="text-2xl font-bold mb-6 text-center">Form Lamaran</h2>
        <input className="input mb-3" type="number" name="jobId" placeholder="ID Lowongan" value={formData.jobId} onChange={handleChange} required />
        <input className="input mb-3" type="text" name="name" placeholder="Nama" value={formData.name} onChange={handleChange} required />
        <input className="input mb-3" type="email" name="email" placeholder="Email" value={formData.email} onChange={handleChange} required />
        <input className="input mb-3" type="file" name="resume" accept=".pdf" onChange={handleChange} required />
        <button type="submit" className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded w-full">Kirim Lamaran</button>
      </form>
    </div>
  );
}

export default ApplyForm;
