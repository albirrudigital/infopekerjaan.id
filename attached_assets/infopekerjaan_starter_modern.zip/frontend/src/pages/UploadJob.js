import React, { useState } from 'react';
import axios from 'axios';

function UploadJob() {
  const [formData, setFormData] = useState({ title: '', description: '', location: '', company: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post(`${process.env.REACT_APP_API_URL}/api/jobs/upload`, formData);
    alert('Job berhasil ditambahkan!');
    setFormData({ title: '', description: '', location: '', company: '' });
  };

  return (
    <div className="flex justify-center items-center h-screen">
      <form onSubmit={handleSubmit} className="bg-white p-8 rounded-lg shadow-md w-96">
        <h2 className="text-2xl font-bold mb-6 text-center">Upload Lowongan</h2>
        <input className="input mb-3" type="text" name="title" placeholder="Posisi" value={formData.title} onChange={handleChange} required />
        <input className="input mb-3" type="text" name="company" placeholder="Perusahaan" value={formData.company} onChange={handleChange} required />
        <input className="input mb-3" type="text" name="location" placeholder="Lokasi" value={formData.location} onChange={handleChange} required />
        <textarea className="input mb-3" name="description" placeholder="Deskripsi" value={formData.description} onChange={handleChange} required></textarea>
        <button type="submit" className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded w-full">Upload</button>
      </form>
    </div>
  );
}

export default UploadJob;
